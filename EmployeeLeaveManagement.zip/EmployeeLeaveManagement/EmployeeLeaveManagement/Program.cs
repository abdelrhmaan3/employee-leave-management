using EmployeeLeaveManagement.Application;
using EmployeeLeaveManagement.Persistence;
using EmployeeLeaveManagement.Service;

namespace EmployeeLeaveManagement
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            builder.Services.ConfigurePersistence(builder.Configuration);
            builder.Services.ConfigureApplication(builder.Configuration);
            builder.Services.ConfigureService();
            //builder.Services.AddJwtAuthentication(builder.Configuration);


            // Add services to the container.
            builder.Services.AddAuthorization(options =>
            {
                options.AddPolicy("AdminOnly", policy => policy.RequireRole("admin"));
            });

            // Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
            builder.Services.AddOpenApi();
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen(SwaggerConfiguration.Configure);
            var app = builder.Build();

            app.UseAuthentication();
            app.UseAuthorization();
            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.MapOpenApi();
                app.UseSwagger();
                app.UseSwaggerUI();

            }

            APIRouteHandler.RegisterWebAppAPIs(app);


            app.Run();
        }
    }
}
