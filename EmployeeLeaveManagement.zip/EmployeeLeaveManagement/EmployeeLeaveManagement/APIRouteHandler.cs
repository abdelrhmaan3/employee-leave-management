﻿using EmployeeLeaveManagement.Application.DTOs;
using EmployeeLeaveManagement.Application.JWT;
using EmployeeLeaveManagement.Application.Repository;
using EmployeeLeaveManagement.Application.Service;
using EmployeeLeaveManagement.Domain;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using EmployeeLeaveManagement.Application.ExceptionsAndValidations;

namespace EmployeeLeaveManagement;

public static class APIRouteHandler
{

    public static void RegisterWebAppAPIs(WebApplication app)
    {
        #region User APIs
        app.MapPost("/Register", Register)
.WithName("Register")
.WithOpenApi();

        app.MapPost("/LogIn", LogIn)
.WithName("LogIn")
.WithOpenApi();
        #endregion

        app.MapGet("leave/GetById", GetById)
    .RequireAuthorization()
    .WithName("GetById")
    .WithOpenApi();

        app.MapGet("leave/Get", Get)
.RequireAuthorization()
.WithName("Get")
.WithOpenApi();

        app.MapPost("leave/Add", Add)
 .RequireAuthorization()
.WithName("Add")
.WithOpenApi();

        app.MapPut("leave/Approve", Approve)
.RequireAuthorization()
.WithName("Approve")
.WithOpenApi();

        app.MapPut("leave/Reject", Reject)
.RequireAuthorization()
.WithName("Reject")
.WithOpenApi();

//        app.MapGet("GetToken", GetToken)
//.WithName("GetToken")
//.WithOpenApi();

    }

    static async Task<IResult> GetById([FromServices] ILeaveRequestService service, Guid ID)
    {
        var Item = await service.GetByID(ID);
        if (Item is null)
        {
            return TypedResults.NotFound();
        }
        return TypedResults.Ok(Item);
    }

    static async Task<IResult> Get([FromServices] ILeaveRequestService service, Guid? employeeID, DateTime? startDate, DateTime? endDate, int pageSize = 10, int pageNumber = 0)
    {

        var result = await service.GetAllLeaveRequests(employeeID, startDate, endDate, pageSize, pageNumber);
        if (result.Count > 0)
        {
            return TypedResults.Ok(result);
        }
        return TypedResults.NotFound();
    }
    static async Task<IResult> Add([FromBody] LeaveRequestAddDTO leaveRequest, [FromServices] ILeaveRequestService service)
    {
        List<ValidationResult> validationResults = new();
        if (!Validator.TryValidateObject(leaveRequest, new ValidationContext(leaveRequest), validationResults, true))
        {
            string validationErrorMessages = "";
            foreach (var validationResult in validationResults)
            {
                validationErrorMessages += validationResult.ErrorMessage;
            }
            return TypedResults.BadRequest(validationErrorMessages);
        }

        var result = await service.CreateLeaveRequest(leaveRequest);
        if (result == "leave request added successfuly")
        {
            return TypedResults.Created(result);
        }
        return TypedResults.BadRequest(result);
    }
    static async Task<IResult> Approve([FromServices] ILeaveRequestService service, [FromQuery] Guid ID)
    {
        return TypedResults.Ok(await service.UpdateLeaveRequest(1, ID));
    }
    static async Task<IResult> Reject([FromServices] ILeaveRequestService service, [FromQuery] Guid ID)
    {
        return TypedResults.Ok(await service.UpdateLeaveRequest(2, ID));
    }

    static async Task<IResult> GetToken([FromServices] TokenService service)
    {
        var Item = service.GenerateToken("1235", "testc@gmail.com", "admin");
        if (Item is null)
        {
            return TypedResults.NotFound();
        }
        return TypedResults.Ok(Item);
    }

    static async Task<IResult> Register([FromBody] RegisterUser RequestUser, [FromServices] IUserAuth userService)
    {
        var result = await userService.RegisterUser(RequestUser);
        var Errors = new List<Error>();
        if (!result.Succeeded)
        {
            foreach (var error in result.Errors)
            {
                var Error = new Error { Code = error.Code, Description = error.Description };
                Errors.Add(Error);
            }
            return TypedResults.BadRequest(Errors);
        }
        return TypedResults.Ok(result.Succeeded);
    }
    static async Task<IResult> LogIn(LoginRequestDTO RequestUser, [FromServices] IUserAuth userService, [FromServices] TokenService tokenService)
    {

        if (!await userService.ValidateUser(RequestUser))
            return TypedResults.NotFound("Please enter correct email and password");
        var user = await userService.GetUserByEmail(RequestUser.Email);
        if (user != null)
        {
            var token = tokenService.GenerateToken(user.Id, user.Email);
            return TypedResults.Ok(token);
        }
        return TypedResults.NotFound("Please insert correct email and password");
    }
}
