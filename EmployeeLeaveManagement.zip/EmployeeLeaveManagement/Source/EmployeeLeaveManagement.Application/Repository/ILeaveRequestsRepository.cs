﻿using EmployeeLeaveManagement.Application.DTOs;
using EmployeeLeaveManagement.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLeaveManagement.Application.Repository;

public interface ILeaveRequestsRepository : IBaseRepository<LeaveRequest>
{
    Task<LeaveRequest?> GetByID(Guid leaveReuestID);
    IQueryable<LeaveRequest> GetAllLeaveRequests();
    Task CreateLeaveRequest(LeaveRequest leaveRequest);
    Task UpdateLeaveRequest(LeaveRequest leaveRequest);
}
