﻿using EmployeeLeaveManagement.Application.DTOs;
using EmployeeLeaveManagement.Domain;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLeaveManagement.Application.Repository;

public interface IUserAuth
{
    Task<IdentityResult> RegisterUser(RegisterUser userForRegistration);
    Task<bool> ValidateUser(LoginRequestDTO userForAuth);
    Task<Employee> GetUserByEmail(string email);
}