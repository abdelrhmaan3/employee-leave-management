﻿using EmployeeLeaveManagement.Application.DTOs;
using EmployeeLeaveManagement.Application.JWT;
using EmployeeLeaveManagement.Domain;
using Mapster;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Reflection;

namespace EmployeeLeaveManagement.Application;

public static class ServiceExtensions
{
    public static void ConfigureApplication(this IServiceCollection services, IConfiguration configuration)
    {
        TypeAdapterConfig<LeaveRequest, LeaveRequestGetDTO>.NewConfig().TwoWays().PreserveReference(false);
        TypeAdapterConfig<Employee, RegisterUser>.NewConfig().TwoWays().PreserveReference(false);

        services.AddTransient<JwtConfiguration>(sp =>
        {
            return new JwtConfiguration(configuration); 
        });
        services.AddTransient<TokenService>();
        services.AddJwtAuthentication(configuration);
    }
  
}
