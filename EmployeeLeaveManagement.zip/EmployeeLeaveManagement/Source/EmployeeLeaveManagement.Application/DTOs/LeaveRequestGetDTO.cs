﻿using EmployeeLeaveManagement.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLeaveManagement.Application.DTOs;

public class LeaveRequestGetDTO
{
    public required Guid ID { get; set; }
    public required Guid EmployeeId { get; set; }
    public required DateTime StartDate { get; set; }
    public required DateTime EndDate { get; set; }
    public string? Reason { get; set; }
    public LeaveStatus? Status { get; set; }
    public DateTimeOffset? DateCreated { get; set; }
}
