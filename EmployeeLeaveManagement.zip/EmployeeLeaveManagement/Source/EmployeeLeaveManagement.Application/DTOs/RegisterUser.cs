﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLeaveManagement.Application.DTOs;

public record RegisterUser
{
    [Required(ErrorMessage = "Name is required")]
    public required string Name { get; set; }
    [Required(ErrorMessage = "Username is required")]
    public required string UserName { get; init; }
    [Required(ErrorMessage = "Password is required")]
    public required string Password { get; init; }
    [Required(ErrorMessage = "Email is required")]
    public required string Email { get; init; }
    [Required(ErrorMessage = "Phone Number is required")]
    public required string PhoneNumber { get; set; }
    public string? Role { get; set; }
    public string? Adress { get; set; }
    public bool? Gender { get; set; }
}
