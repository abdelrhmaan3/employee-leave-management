﻿using EmployeeLeaveManagement.Application.ExceptionsAndValidations;
using EmployeeLeaveManagement.Domain;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLeaveManagement.Application.DTOs;

public class LeaveRequestAddDTO
{
    [Required]
    public required Guid EmployeeId { get; set; }
    [Required]
    public required DateTime StartDate { get; set; }
    [Required]
    [EndDateGreaterThanStartDateAttribute]
    public required DateTime EndDate { get; set; }
    public string? Reason { get; set; }
    public LeaveStatus? Status { get; set; }
    public DateTimeOffset? DateCreated { get; set; }
}
