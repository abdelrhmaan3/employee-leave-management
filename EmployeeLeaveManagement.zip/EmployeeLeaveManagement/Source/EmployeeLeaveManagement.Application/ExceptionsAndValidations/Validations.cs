﻿using EmployeeLeaveManagement.Application.DTOs;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLeaveManagement.Application.ExceptionsAndValidations;

public class EndDateGreaterThanStartDateAttribute : ValidationAttribute
{
    public EndDateGreaterThanStartDateAttribute()
    {
        ErrorMessage = "End date must not be earlier than start date.";
    }
    protected override ValidationResult IsValid(object value, ValidationContext validationContext)
    {
        var model = (LeaveRequestAddDTO)validationContext.ObjectInstance;
        if (model == null)
        {
            return new ValidationResult("Invalid model.");
        }
        if (model.EndDate < model.StartDate)
        {
            return new ValidationResult(ErrorMessage);
        }
        return ValidationResult.Success;
    }
} 