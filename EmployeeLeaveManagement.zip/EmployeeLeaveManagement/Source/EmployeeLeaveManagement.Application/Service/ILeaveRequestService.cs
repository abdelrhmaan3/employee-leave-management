﻿using EmployeeLeaveManagement.Application.DTOs;
using EmployeeLeaveManagement.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLeaveManagement.Application.Service;

public interface ILeaveRequestService
{
    Task<LeaveRequestGetDTO> GetByID(Guid leaveRequestID);
    Task<List<LeaveRequestGetDTO>> GetAllLeaveRequests(Guid? employeeID, DateTime? startDate, DateTime? endDate, int pageSize = 10, int pageNumber = 0);
    Task<string> CreateLeaveRequest(LeaveRequestAddDTO leaveRequest);
    Task<string> UpdateLeaveRequest(int status, Guid ID);
}
