﻿using EmployeeLeaveManagement.Application.DTOs;
using EmployeeLeaveManagement.Application.Repository;
using EmployeeLeaveManagement.Domain;
using Mapster;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLeaveManagement.Service.Services;

public class UserAuth : IUserAuth
{
    private readonly UserManager<Employee> _userManager;
    private readonly IConfiguration _configuration;

    private Employee? _user;

    public UserAuth(UserManager<Employee> userManager, IConfiguration configuration)
    {
        _userManager = userManager;
        _configuration = configuration;
    }

    public async Task<IdentityResult> RegisterUser(RegisterUser userForRegistration)
    {
        var user = userForRegistration.Adapt<Employee>();
        var result = await _userManager.CreateAsync(user, userForRegistration.Password);
        //if (result.Succeeded && userForRegistration.Role != null)
        //{
        //  await _userManager.AddToRoleAsync(user, userForRegistration.Role);
        //}
        return result;
    }

    public async Task<bool> ValidateUser(LoginRequestDTO userForAuth)
    {
        _user = await _userManager.FindByEmailAsync(userForAuth.Email);
        var result = (_user != null && await _userManager.CheckPasswordAsync(_user, userForAuth.Password));
        return result;
    }
    public async Task<Employee> GetUserByEmail(string email)
    {
        return await _userManager.FindByEmailAsync(email);
    }
}
