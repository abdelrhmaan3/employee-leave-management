﻿using EmployeeLeaveManagement.Application.DTOs;
using EmployeeLeaveManagement.Application.Repository;
using EmployeeLeaveManagement.Application.Service;
using EmployeeLeaveManagement.Domain;
using Mapster;
using Microsoft.EntityFrameworkCore;

namespace EmployeeLeaveManagement.Service.Services;

public class LeaveRequestService : ILeaveRequestService
{
    private readonly ILeaveRequestsRepository _leaveRequestsRepository;
    public LeaveRequestService(ILeaveRequestsRepository leaveRequestsRepository)
    {
        _leaveRequestsRepository = leaveRequestsRepository;
    }

    public async Task<string> CreateLeaveRequest(LeaveRequestAddDTO leaveRequest)
    {
        try
        {
            var overlapedItem = await _leaveRequestsRepository.GetAllLeaveRequests().AnyAsync(x => leaveRequest.StartDate < x.EndDate && leaveRequest.EndDate > x.StartDate);
            if (overlapedItem)
            {
                return "you are overlaping an exist leave request";
            }
            var item = leaveRequest.Adapt<LeaveRequest>();
            await _leaveRequestsRepository.CreateLeaveRequest(item);
            return "leave request added successfuly";
        }
        catch (Exception ex)
        {

            return $"Exception : {ex.Message}, Ineer Exception : {ex.InnerException?.Message}";
        }

    }

    public async Task<List<LeaveRequestGetDTO>> GetAllLeaveRequests(Guid? employeeID, DateTime? startDate, DateTime? endDate, int pageSize = 10, int pageNumber = 0)
    {
        var query = _leaveRequestsRepository.GetAllLeaveRequests();
        if (startDate != null && endDate != null)
        {
            query = query.Where(x => x.StartDate == startDate && x.EndDate == endDate);
        }
        List<LeaveRequest> items = await query.Skip(pageNumber).Take(pageSize).OrderBy(x => x.DateCreated).ToListAsync();
        if (items == null || !items.Any())
        { return new List<LeaveRequestGetDTO>(); }

        return items.Adapt<List<LeaveRequestGetDTO>>();
    }

    public async Task<LeaveRequestGetDTO> GetByID(Guid leaveRequestID)
    {
        var item = await _leaveRequestsRepository.GetByID(leaveRequestID);
        return item.Adapt<LeaveRequestGetDTO>();
    }
    public async Task<string> UpdateLeaveRequest(int status, Guid ID)
    {
        try
        {
        var item = await _leaveRequestsRepository.GetByID(ID);
        if (item is null)
        {
            return "This leave request not exist";
        }
        item.Status = (LeaveStatus)status;
        await _leaveRequestsRepository.UpdateLeaveRequest(item);
            return $"Leave Request {item.Status}";
        }
        catch (Exception ex)
        {

            return ex.Message;
        }

    }
}
