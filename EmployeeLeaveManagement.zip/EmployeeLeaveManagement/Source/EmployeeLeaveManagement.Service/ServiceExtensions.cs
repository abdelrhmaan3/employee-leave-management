﻿using EmployeeLeaveManagement.Application.DTOs;
using EmployeeLeaveManagement.Application.Repository;
using EmployeeLeaveManagement.Application.Service;
using EmployeeLeaveManagement.Domain;
using EmployeeLeaveManagement.Service.Services;
using Mapster;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLeaveManagement.Service;

public static class ServiceExtensions
{
    public static void ConfigureService(this IServiceCollection services)
    {
        services.AddScoped<ILeaveRequestService, LeaveRequestService>();
        services.AddScoped<IUserAuth, UserAuth>();
    }

}
