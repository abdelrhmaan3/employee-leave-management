﻿using EmployeeLeaveManagement.Domain;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLeaveManagement.Persistence;

public class BriteContext : DbContext
{
    public DbSet<LeaveRequest> LeaveRequests { get; set; }
    public DbSet<Employee> Employees { get; set; }
    public DbSet<Role> Roles { get; set; }
    public DbSet<UserRole> UserRoles { get; set; }
    protected override void OnConfiguring(DbContextOptionsBuilder OptionsBuilder)
    {
        if (OptionsBuilder.IsConfigured) return;
        //OptionsBuilder.UseSqlServer("server=.;database=EjadDb;trusted_connection=true;");
        OptionsBuilder.UseSqlServer("Server=DESKTOP-41ISMFG\\SQLEXPRESS;Database=BriteDb;Integrated Security=True;TrustServerCertificate=True;");

        OptionsBuilder
              .EnableDetailedErrors()
              .EnableSensitiveDataLogging();
    }
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
         modelBuilder.Entity<Employee>()
        .HasMany(u => u.LeaveRequest)
        .WithOne(n => n.Employee)
        .HasForeignKey(n => n.EmployeeId);

        modelBuilder.Entity<Role>().ToTable("Roles")
            .HasKey(r => r.Id);

        modelBuilder.Entity<UserRole>()
        .HasKey(ur => new { ur.UserId, ur.RoleId });


        modelBuilder.Entity<UserRole>()
       .HasOne(ur => ur.Employee)
       .WithMany(e => e.UserRoles)
       .HasForeignKey(ur => ur.UserId)
       .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<UserRole>()
            .HasOne(ur => ur.Role)
            .WithMany(r => r.UserRoles)
            .HasForeignKey(ur => ur.RoleId)
            .OnDelete(DeleteBehavior.Cascade);

    }
}
