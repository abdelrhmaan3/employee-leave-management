﻿using EmployeeLeaveManagement.Application.DTOs;
using EmployeeLeaveManagement.Application.Repository;
using EmployeeLeaveManagement.Domain;
using Mapster;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLeaveManagement.Persistence.Repository;

public class LeaveRequestsRepository : BaseRepository<LeaveRequest>, ILeaveRequestsRepository
{
    private readonly IUnitOfWork _unitOfWork;
    public LeaveRequestsRepository(BriteContext context, IUnitOfWork unitOfWork) : base(context)
    {   
        _unitOfWork = unitOfWork;
    }
    public async Task<LeaveRequest?> GetByID(Guid leaveRequestID)
    {
        return await Context.LeaveRequests.FindAsync(leaveRequestID);
    }
    public IQueryable<LeaveRequest> GetAllLeaveRequests()
    {
       return Context.LeaveRequests.AsQueryable();
    }

    public async Task CreateLeaveRequest(LeaveRequest leaveRequest)
    {
      await Context.LeaveRequests.AddAsync(leaveRequest);
      await  _unitOfWork.Save();
    }
    public async Task UpdateLeaveRequest(LeaveRequest leaveRequest)
    {
        Context.LeaveRequests.Update(leaveRequest);
        await _unitOfWork.Save();
    }
}
