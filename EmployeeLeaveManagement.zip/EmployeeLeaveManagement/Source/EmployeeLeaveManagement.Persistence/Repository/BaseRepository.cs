﻿using EmployeeLeaveManagement.Application.Repository;
using EmployeeLeaveManagement.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLeaveManagement.Persistence.Repository
{
    public class BaseRepository<T> : IBaseRepository<T> where T : BaseEntity
    {
        protected readonly BriteContext Context;

        public BaseRepository(BriteContext context)
        {
            Context = context;
        }

        public void Create(T entity)
        {
            Context.Add(entity);
        }
        public void Update(T entity)
        {
            Context.Update(entity);
        }
        public Task<T> Get(Guid id)
        {
            return Context.Set<T>().FirstOrDefaultAsync(x => x.ID == id);
        }

        public Task<List<T>> GetAll()
        {
            return Context.Set<T>().ToListAsync();
        }
    }
}
