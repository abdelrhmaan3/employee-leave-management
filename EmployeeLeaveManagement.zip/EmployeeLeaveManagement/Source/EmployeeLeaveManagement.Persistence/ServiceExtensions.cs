﻿using EmployeeLeaveManagement.Application.Repository;
using EmployeeLeaveManagement.Application.Service;
using EmployeeLeaveManagement.Domain;
using EmployeeLeaveManagement.Persistence.Repository;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace EmployeeLeaveManagement.Persistence;

public static class ServiceExtensions
{
    public static void ConfigurePersistence(this IServiceCollection services, IConfiguration configuration)
    {
        //var connection = configuration.GetConnectionString("BriteContext");
        //services.AddDbContext<BriteContext>(options => options.UseSqlServer(connection));
        services.AddScoped<IUnitOfWork, UnitOfWork>();
        services.AddScoped<ILeaveRequestsRepository, LeaveRequestsRepository>();
        services.AddDbContext<BriteContext>();
        services.AddIdentity<Employee, IdentityRole>().AddEntityFrameworkStores<BriteContext>();
    }
}
