﻿using System.ComponentModel.DataAnnotations.Schema;

namespace EmployeeLeaveManagement.Domain;
public class LeaveRequest:BaseEntity

{
    public required string EmployeeId { get; set; }
    public required DateTime StartDate { get; set; }
    public required DateTime EndDate { get; set; }
    public string? Reason { get; set; }
    public LeaveStatus? Status { get; set; } 
    public Employee? Employee { get; set; }
}
public enum LeaveStatus
{
    Pending = 0,
    Approved = 1,
    Rejected = 2
}
