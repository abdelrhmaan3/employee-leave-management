﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLeaveManagement.Domain;

public class Employee : IdentityUser
{
    public required string Name { get; set; }
    public string? Adress { get; set; }
    public bool? Gender { get; set; }
    public DateTimeOffset DateCreated { get; set; } = DateTimeOffset.Now;
    public ICollection<LeaveRequest> LeaveRequest { get; } = [];
    public ICollection<UserRole> UserRoles { get; } = [];

}
